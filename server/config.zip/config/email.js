var nodemailer = require("nodemailer");
var hbs = require("nodemailer-express-handlebars");
const nodemailerSendgrid = require("nodemailer-sendgrid");
var path = require("path");
const email = {};
email.transporter = nodemailer.createTransport(
  nodemailerSendgrid({
    apiKey:
      process.env.emailkey,
  })
);

var options = {  
  viewEngine: {
    extname: ".hbs",

    layoutsDir: path.resolve("./templates/"), 

    defaultLayout: "template",

    partialsDir: path.resolve("./templates/"), 
  },

  viewPath: path.resolve("./templates/"),

  extName: ".hbs",
};

email.transporter.use("compile", hbs(options));

module.exports = email;
 